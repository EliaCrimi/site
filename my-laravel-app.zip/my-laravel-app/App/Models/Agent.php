<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Agent extends Model
{
    protected $table = 'agents'; // Specify the table name if it differs from the model name convention

    protected $primaryKey = ['username', 'agent']; // Specify the composite primary key

    public $incrementing = false; // Disable auto-incrementing for composite keys

    protected $keyType = 'string'; // Specify the data type of the primary key

    protected $fillable = [
        'username', 'agent', 'img',
    ];

    // Optionally, define relationships or additional methods as needed
}

}
