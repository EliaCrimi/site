<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Likes extends Model
{
    protected $table = 'likes'; // Specify the actual table name if different
    protected $primaryKey = null; // Since we have composite primary key

    public $incrementing = false; // Disable auto-incrementing for composite primary key

    protected $fillable = [
        'username',
        'image_id',
    ];
}
