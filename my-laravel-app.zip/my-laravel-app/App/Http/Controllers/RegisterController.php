<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:5|regex:/[A-Z]/',
        ]);
    
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $hashedPassword = Hash::make($request->password);

        $user = User::create([
            'username' => $request->username,
            'password' => $hashedPassword,
        ]);


        Auth::login($user);
      
        return redirect()->route('welcome');
    }
}


