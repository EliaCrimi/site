<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SessionController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->intended('/'); 
        }

        return redirect()->back()->withErrors(['username' => 'Credenziali non valide'])->withInput();
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect('/accedi');
    }
}

