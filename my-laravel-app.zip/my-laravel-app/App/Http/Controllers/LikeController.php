<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Like;
use Illuminate\Support\Facades\Redirect;


class LikeController extends Controller{

   public function like(Request $request)
   {
       if (Auth::check()) {
           $user = Auth::user();
           $image_id = $request->input('image_id');
           $action = $request->input('action');
      
           if ($action == 'click') {
               DB::table('likes')->insert([
                   'username' => $user->username,
                   'image_id' => $image_id
               ]);
           } else if ($action == 'unclick') {
               DB::table('likes')->where('username', $user->username)->where('image_id', $image_id)->delete();
           }
      
           return response()->json(['status' => 'success']);
       } else {
           return redirect()->route('accedi');
       }
   }

   public function likecheck($numero){
       if (Auth::check()) {
           $username = Auth::user()->username;

           $liked=DB::table('likes')
                      ->where('username', $username)
                      ->where('image_id', $numero)
                      ->exists();
           return response()->json(['liked' => $liked]);
       } else {
           return response()->json(['status' => 'success', 'message' => 'initial checklike: not logged in']);
       }
   }



}



