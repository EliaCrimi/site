<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class APIController extends Controller
{
    public function table($artistiagentiValue){
        if (Auth::check()) {
            $user_id=Auth::user()->username;

            if ($artistiagentiValue === "Agenti") {
                $result=DB::table('agents')
                       ->where('username', $user_id)
                       ->get();
            } else if ($artistiagentiValue === "Artisti") {
                $result=DB::table('artists')
                        ->where('username', $user_id)
                        ->get();
            }

            return response()->json($result);
        } else {
           return redirect()->route('accedi');
        }

        return response()->json(['status' => 'success', 'message' => 'Agent table updated']);
    }
}

