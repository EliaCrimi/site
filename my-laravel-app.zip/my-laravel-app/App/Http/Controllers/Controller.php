<?php

namespace app\Http\Controllers;

abstract class Controller
{
    //
}








?>
