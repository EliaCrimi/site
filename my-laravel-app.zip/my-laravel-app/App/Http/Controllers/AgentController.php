<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Agents;
use Carbon\Carbon;

class AgentController extends Controller
{
    protected $client;

    public function __construct()
    {
        $this->client = new Client([
            'base_uri' => 'https://valorant-api.com/v1/',
            'timeout'  => 2.0,
            'verify'   => false, 
        ]);
    }

    public function getAgent($agent_uuid)
    {
        $response = $this->client->request('GET', 'agents/' . $agent_uuid);
      
        $data = json_decode($response->getBody()->getContents(), true);
      
        return response()->json($data);
    }

    public function AgentTable(Request $request)
    {
        if (Auth::check()) {
            $user_id=Auth::user()->username;
            $urlimg = $request->input('urlimg');
            $agent = $request->input('agent');

            $exists=DB::table('agents')
                      ->where('username', $user_id)
                      ->where('agent', $agent)
                      ->exists();
            if(!$exists){
                DB::table('agents')->insert([
                    'username' => $user_id,
                    'agent' => $agent,
                    'img' => $urlimg,
                    'created_at' => Carbon::now(), 
                    'updated_at' => Carbon::now(), 
                ]);
            } else{
                return response()->json(['status' => 'success', 'message' => 'Already existed']);
            }

            return response()->json(['status' => 'success', 'message' => 'Agent table updated']);
        } else {
           return redirect()->route('accedi');
        }
    }
}
