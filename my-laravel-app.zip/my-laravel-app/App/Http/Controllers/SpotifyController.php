<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Agents;
use Carbon\Carbon;

class SpotifyController extends Controller
{
    private $token;

    public function __construct()
    {
        $this->token = $this->getSpotifyToken();
    }

   private function getSpotifyToken()
   {
       $response = Http::asForm()->withOptions(['verify' => false])->post('https://accounts.spotify.com/api/token', [
           'grant_type' => 'client_credentials',
           'client_id' => '4f9ea3998d244005ae4b56289da1ac4f',
           'client_secret' => "f1037da3ce7b4434ba73b91a07cbd7f7",
       ]);
   
       return $response->json()['access_token'];
   }


   public function searchArtist($artist)
   {
       $response = Http::withHeaders([
           'Authorization' => 'Bearer ' . $this->token,
       ])->withOptions(['verify' => false])->get('https://api.spotify.com/v1/search', [
           'q' => $artist,
           'type' => 'artist',
       ]);
   
       return response()->json($response->json());
   }


   public function ArtistTable(Request $request)
   {
       if(Auth::check()){
           $user_id=Auth::user()->username;
           $urlimg = $request->input('urlimg');
           $artist = $request->input('artist');

           $exists=DB::table('artists')
                      ->where('username', $user_id)
                      ->where('artist', $artist)
                      ->exists();
           if(!$exists){
               DB::table('artists')->insert([
                   'username' => $user_id,
                   'artist' => $artist,
                   'img' => $urlimg,
                   'created_at' => Carbon::now(), 
                   'updated_at' => Carbon::now(), 
               ]);
           } else{
               return response()->json(['status' => 'success', 'message' => 'Already existed']);
           }

           return response()->json(['status' => 'success', 'message' => 'Agent table updated']);
       } else {
           return redirect()->route('accedi');
       }
   }


   
}



