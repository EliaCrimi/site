@extends('layouts.app2')

@section('title', 'GAMING')

@section('script')                                                                        
    <script src="{{ asset('js/gaming.js') }}" defer></script>                             
@endsection                                                                               
                                                                                          
@section('controller', asset('images/controller.png'))                                    
                                                                                          
@section('content')                                                                       
   <p>Genera l'immagine del tuo agente (valorant) preferito!</p>                          
   <form class="gaming">                                                                  
      <label for="agent">Select Agent:</label>                                            
      <select id="agent" name="agent">
           <option value="Gekko">Gekko</option>
           <option value="Fade">Fade</option>
           <option value="Breach">Breach</option>
           <option value="Clove">Clove</option>
           <option value="Deadlock">Deadlock</option>
           <option value="Raze">Raze</option>
           <option value="Chamber">Chamber</option>
           <option value="KAY/O">KAY/O</option>
           <option value="Skye">Skye</option>
           <option value="Cypher">Cypher</option>
           <option value="Sova">Sova</option>
           <option value="Killjoy">Killjoy</option>
           <option value="Harbor">Harbor</option>
           <option value="Viper">Viper</option>
           <option value="Phoenix">Phoenix</option>
           <option value="Astra">Astra</option>
           <option value="Brimstone">Brimstone</option>
           <option value="Iso">Iso</option>
           <option value="Clove">Clove</option>
           <option value="Neon">Neon</option>
           <option value="Yoru">Yoru</option>
           <option value="Sage">Sage</option>
           <option value="Reyna">Reyna</option>
           <option value="Omen">Omen</option>
           <option value="Jett">Jett</option>
      </select>                                                         
      <input type="submit">
   </form>
   <div id="image-container" class="gaming"></div>
@endsection





