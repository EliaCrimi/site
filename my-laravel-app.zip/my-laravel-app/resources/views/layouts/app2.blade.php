<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('css/musicgaming.css') }}">
    <title>@yield('title')!</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&display=swap">
    @yield('script')
</head>

<body>
    <nav>
        <a id="home" href="{{ route('welcome') }}">
            Home
        </a>
        <div id="elia">
            @yield('title')
        </div>
        @if(Auth::check())
             <div class="user"><img src="{{ asset('images/user.png') }}"><div>User: {{ Auth::user()->username }}</div></div>
        @endif
        <img src="@yield('controller')" id="controller">
    </nav>

    <section>
       @yield('content')
    </section>
</body>
</html>

