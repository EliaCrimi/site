<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="{{ asset('css/accedi.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&display=swap">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIGNUP ELIA</title>
</head>

<body>
    <div class="background-image">
        <a href="{{ route('welcome') }}" id="elia">Elia</a>
        <main class="trasparente">
            <h1>Sign Up</h1>
           
            <form method="POST" action="{{ route('sign') }}">
                @csrf
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="username" value="{{ old('username') }}">

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="password">

                <input type="submit" value="Sign Up">

                @error('password')
                    <div class="warning"><img src="{{ asset('images/warning.png') }}"><p>{{ $message }}</p></div>
                @enderror
                @error('username')
                     <div class="warning"><img src="{{ asset('images/warning.png') }}"><p>{{ $message }}</p></div>
                @enderror
            </form>
        </main>

        <section class="trasparente">
            <div class="warning">La Password deve contenere almeno 5 lettere fra cui una maiuscola</div>
            <a href="{{ route('accedi') }}" id="scambio">Hai già un Account?</a>
        </section>


    </div>
</body>
</html>
