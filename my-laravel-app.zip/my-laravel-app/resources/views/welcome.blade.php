<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&display=swap">
    <link rel="stylesheet" href="{{ asset('css/mhw3.css') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="{{ asset('js/mhw3.js') }}" defer></script>
    <title>HW1</title>
</head>

<body>
    <article>
        <nav>
            <div id="info">Accedi</div>
            <h1>Elia Crimi</h1>
            <a href="{{ route('logout') }}" id="logout"><img src="{{ asset('images/logout.webp') }}"></a>
            @if(Auth::check())
                 <div class="user"><img src="{{ asset('images/user.png') }}"><div>User: {{ Auth::user()->username }}</div></div>
            @endif
        </nav>

        <div class="hidden accedi">
            <button onclick="window.location.href='{{ route('accedi') }}';" id="acc">Clicca qui per accedere<img src="{{ asset('images/accesso.png') }}"></button>
            <button onclick="window.location.href='{{ route('registra') }}';" id="reg">Clicca qui per registrarti<img src="{{ asset('images/signup.png') }}"></button>
            <img id="x" src="{{ asset('images/croce.png') }}">
        </div>


        <header>IL MIO SITO</header>
        <p>Uno dei siti di sempre.</p>
    </article>

    <section data-grandezza="piccolo">
        <h2>Le mie Passioni</h2>

        <div class="primo paio">
            <div class="section-item img1">
                <a href='{{ route('gaming') }}'>GAMING</a>
                <img src="{{ asset('images/unclickedlike.png') }}" class="likebutton"  data-numero="1"> 
            </div>

            <div class="section-item img2">
                <a href='{{ route('music') }}'>MUSIC</a>
                <img src="{{ asset('images/unclickedlike.png') }}" class="likebutton"  data-numero="2"> 
            </div>
        </div>

        <div class="paio">
            <div class="section-item img3">
                <p>GYM</p>
                <img src="{{ asset('images/unclickedlike.png') }}" class="likebutton"  data-numero="3"> 
            </div>
            <div class="section-item img4">
                <p>COMPUTER ENGINEERING</p>
                <img src="{{ asset('images/unclickedlike.png') }}" class="likebutton"  data-numero="4"> 
            </div>
        </div>

        <div class="hidden paio" id="terzopaio">
            <div class="section-item img5">
                <p>ANIME</p>
                <img src="{{ asset('images/unclickedlike.png') }}" class="likebutton"  data-numero="5"> 
            </div>
            <div class="section-item img6">
                <p class="API">APIs</p>
                <img src="{{ asset('images/unclickedlike.png') }}" class="likebutton inverti-colori"  data-numero="6"> 
            </div>
        </div>

        <button>Tutte le mie Passioni</button>

    </section>

    <div id="section2"><p>Informazioni universitarie:</p><em>Matricola: 10000303444</em></div>

    <div id="section3">
        <img src="{{ asset('images/vinland1.avif') }}" />
        <p>I have no enemies</p><em>- Thorfinn</em>
    </div>


    <footer>
        <div id="nome">Elia</div>
        <div id="quote">*The quote from above is not to be taken seriously<br>It was added only for comedic purposes</div>
        <img id="thumbsup" src="{{ asset('images/thumbsup.webp') }}"></img>
    </footer>

    <div class="modal-view hidden">
        <img src="{{ asset('images/croce.png') }}" class="croce"> 
        <div id="whiteboard">
            <form id="myForm">
                <label for="artistiagenti">Vuoi vedere i tuoi agenti o i tuoi artisti salvati?:</label>
                <select id="formvalue" name="formvalue">
                     <option value="Artisti">Artisti</option>
                     <option value="Agenti">Agenti</option>
                </select>                               
                <input type="submit">
            </form>
            <div id="contieni-foto"></div>
        </div>
    </div>

</body>
</html>

