@extends('layouts.app2')

@section('title', 'MUSIC')

@section('script')
    <script src="{{ asset('js/music.js') }}" defer></script>
@endsection

@section('controller', "https://thumbs.dreamstime.com/b/vector-electric-guitar-fire-design-vector-illustration-electric-guitar-fire-design-additional-format-eps-separate-layers-169404788.jpg")

@section('content')
   <form class="music">
       <input type="text" id="artist" placeholder="Artist">
       <input type="submit">
   </form>

   <div id="image-container" class="music"> </div>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
@endsection

