 <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="{{ asset('css/accedi.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&display=swap">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LOG IN ELIA</title>
</head>

<body>

    <div class="background-image">
        <a href="{{ route('welcome') }}" id="elia">Elia</a>
        <main class="trasparente">
            <h1>Log In</h1>
            <form method="post" action="{{ route('accedi.submit') }}">
                @csrf
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="username">

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="password">

                <input type="submit" value="log IN">

                @error('username')
                     <div class="warning"><img src="{{ asset('images/warning.png') }}"><p>{{ $message }}</p></div>
                @enderror
            </form>
        </main>

        <section class="trasparente">
           <a href="{{ route('registra') }}" id="scambio">Non Hai un account?<br>Registrati Ora!</a>
        </section>
    </div>

</body>
</html>
