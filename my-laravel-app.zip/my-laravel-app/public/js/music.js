
const form = document.querySelector('.music');

form.addEventListener('submit', function (event) {
    event.preventDefault();
    const artist = document.querySelector('#artist').value;
    console.log(artist);
    searchArtist(artist);
});

function searchArtist(artist) {
    axios.get(`/search/${encodeURIComponent(artist)}`)
        .then(response => {
            console.log('Response:', response);
            onJson(response.data);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}


function onJson(json) {
    console.log(json);
    const artistItems = json.artists.items;
    if (artistItems.length > 0) {
        const artist = artistItems[0];
        const images = artist.images;
        if (images.length > 0) {
            const urlimg = images[0].url;
            console.log("URL: ", urlimg);
            const artistContainer = document.getElementById('image-container');
            artistContainer.innerHTML = '';

            const contieniImg = document.createElement('div');
            contieniImg.classList.add('contieniImg');
            artistContainer.appendChild(contieniImg);

            const artistImage = document.createElement('img');
            artistImage.src = urlimg;
            contieniImg.appendChild(artistImage);
            artistImage.classList.add('ArtistaImmagine');

            const aggiungi = document.createElement('img');
            aggiungi.src = "images/add.jpg";
            aggiungi.classList.add('addmusic');
            contieniImg.appendChild(aggiungi);

            aggiungi.setAttribute("nome", artist.name);
            aggiungi.setAttribute("img", urlimg);
            aggiungi.addEventListener("click", fadd);
        }
    }
}







function fadd(event) {
    console.log("click");
    const el = event.currentTarget;
    const nome = el.getAttribute("nome");
    const img = el.getAttribute("img");
    console.log(nome);
    console.log(img);

    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    fetch('/artisttable', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify({
            artist: nome,
            urlimg: img
        })
    })
    .then(response => {
        if (response.redirected) {
            window.location.href = response.url;
        } else {
            return response.json();
        }
    })
    .then(data => {
        console.log(data);
    });

}


