
const Thorfinn = document.querySelector("#section3 img");
Thorfinn.addEventListener("click", ClickThorfinn);

function ClickThorfinn(event) {
    console.log("Thorfinn Clicked");
    const el = event.currentTarget;
    el.src = "images/vinland2.jpg";
    const p = document.querySelector("#section3 p");
    p.textContent = "YOU have no enemies";
    const section3 = document.querySelector("#section3");
    section3.classList.add("black");
}

const thumbsup = document.querySelector("#thumbsup");
thumbsup.addEventListener("click", ClickB);

function ClickB(event) {
    const Thorfinn = document.querySelector("#section3 img");
    Thorfinn.src = "images/vinland1.avif";
    const p = document.querySelector("#section3 p");
    p.textContent = "I have no enemies";
    const section3 = document.querySelector("#section3");
    section3.classList.remove("black");
}




const info = document.querySelector("#info");
info.addEventListener("click", finfo);

function finfo() {
    console.log("accedi");
    const el = document.querySelector("article .accedi");
    if (el.classList.contains("hidden")) {
        el.classList.remove("hidden");
    } else { console.log("non accesso"); }
}


const x = document.querySelector("#x");
x.addEventListener("click", fx);

const vett = document.querySelectorAll(".accedi button");
vett.forEach(function (elemento) {
    elemento.addEventListener("click", fx);
});


function fx(event) {
    console.log("x");
    const el = document.querySelector("article .accedi");
    el.classList.add("hidden");
}






const passion = document.querySelector("section button");
passion.addEventListener("click", fpassion);

function fpassion(event) {
    const sect = document.querySelector("section");
    sect.dataset.grandezza = "grande";
    const terzop = document.querySelector("#terzopaio");
    terzop.classList.remove("hidden");
    const button = event.currentTarget;
    button.textContent = "Torna indietro";
    passion.removeEventListener("click", fpassion);
    passion.addEventListener("click", passionindietro);
}

function passionindietro(event) {
    const sect = document.querySelector("section");
    sect.dataset.grandezza = "piccolo";
    const terzop = document.querySelector("#terzopaio");
    terzop.classList.add("hidden");
    const button = event.currentTarget;
    button.textContent = "Tutte le mie Passioni";
    passion.removeEventListener("click", passionindietro);
    passion.addEventListener("click", fpassion);
}








const mipiace = document.querySelectorAll(".likebutton");
mipiace.forEach(function (elemento) {
    elemento.addEventListener("click", fmipiace);
});
function fmipiace(event) {
    const el = event.currentTarget;
    const numero = el.dataset.numero;
    let action;

    if (el.src.includes("unclickedlike.png")) {

        el.src = "images/like.png";
        if (el.classList.contains('inverti-colori')) {
            el.classList.remove('inverti-colori');
        }
        action = "click";
    }
    else if (el.src.includes("like.png")) {

        el.src = "images/unclickedlike.png";
        if (numero === '6') {
            el.classList.add('inverti-colori');
        }
        action = "unclick";
    }
    console.log(numero);
    console.log(action);

    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch('/like', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken 
        },
        body: JSON.stringify({
            image_id: numero,
            action: action
        })
    })
    .then(response => {
        if (response.redirected) {
            window.location.href = response.url;
        } else {
            return response.json();
        }
    })
    .then(data => {
        console.log(data);
    });

}





mipiace.forEach(checklike);

function checklike(elemento) {
    const el = elemento;
    const numero = el.dataset.numero;
    console.log(numero);
    fetch(`/likecheck/${numero}`)
        .then(onCheckLike).then(json => JsonCheckLike(json, el))
        .catch(error => { console.error('Fetch error:', error); });
}

function onCheckLike(response) {
    return response.json();
}

function JsonCheckLike(json, el) {
    console.log(json);
    const like = json['liked'];

    if (like === true) {
        el.src = "images/like.png";
        if (el.classList.contains('inverti-colori')) {
            el.classList.remove('inverti-colori');
        }
    }
}





const API = document.querySelector('.API');
API.addEventListener("click", apiclick);

function apiclick(event) {
    console.log("modal");
    document.body.classList.add('noscroll');
    const modalView = document.querySelector(".modal-view");
    modalView.style.top = window.pageYOffset + 'px';
    modalView.classList.remove('hidden');
}

const XX = document.querySelector(".modal-view .croce");
XX.addEventListener('click', modalclick);

function modalclick() {
    const modalView = document.querySelector(".modal-view");
    document.body.classList.remove('noscroll');
    modalView.classList.add('hidden');
}




const APIform = document.getElementById('myForm');
APIform.addEventListener("submit", fapi);

function fapi(event) {
    const API = document.querySelector('#formvalue');
    const API_value = encodeURIComponent(API.value);
    event.preventDefault();

    console.log('Form parameters:', API_value);

    fetch(`/API/${API_value}`).then(apiResponse).then(apiJson);
}




function apiResponse(response) {
    return response.json();
}

function apiJson(Json) {
    console.log(Json);
    const modalView = document.querySelector("#contieni-foto");

    Json.forEach(function (obj) {
        const div = document.createElement("div");
        modalView.appendChild(div);
        div.classList.add('img-container');

        const img = document.createElement("img");
        img.src = obj.img;
        div.appendChild(img);


        const name = document.createElement("div");
        if (typeof obj.agent !== 'undefined') {

            name.textContent = obj.agent;
        }
        if (typeof obj.artist !== 'undefined') {
            name.textContent = obj.artist;
        }

        div.appendChild(name);
    })

}
