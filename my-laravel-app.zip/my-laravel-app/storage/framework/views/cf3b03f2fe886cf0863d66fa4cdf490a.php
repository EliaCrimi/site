

<?php $__env->startSection('title', 'MUSIC'); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/music.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('controller', "https://thumbs.dreamstime.com/b/vector-electric-guitar-fire-design-vector-illustration-electric-guitar-fire-design-additional-format-eps-separate-layers-169404788.jpg"); ?>

<?php $__env->startSection('content'); ?>
   <form class="music">
       <input type="text" id="artist" placeholder="Artist">
       <input type="submit">
   </form>

   <div id="image-container" class="music"> </div>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crimi\OneDrive\Desktop\laravel\my-laravel-app\resources\views/music.blade.php ENDPATH**/ ?>