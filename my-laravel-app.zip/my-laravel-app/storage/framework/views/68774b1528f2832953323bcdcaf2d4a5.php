<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&display=swap">
    <link rel="stylesheet" href="<?php echo e(asset('css/mhw3.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="<?php echo e(asset('js/mhw3.js')); ?>" defer></script>
    <title>HW1</title>
</head>

<body>
    <article>
        <nav>
            <div id="info">Accedi</div>
            <h1>Elia Crimi</h1>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><img src="<?php echo e(asset('images/logout.webp')); ?>"></a>
            <?php if(Auth::check()): ?>
                 <div class="user"><img src="<?php echo e(asset('images/user.png')); ?>"><div>User: <?php echo e(Auth::user()->username); ?></div></div>
            <?php endif; ?>
        </nav>

        <div class="hidden accedi">
            <button onclick="window.location.href='<?php echo e(route('accedi')); ?>';" id="acc">Clicca qui per accedere<img src="<?php echo e(asset('images/accesso.png')); ?>"></button>
            <button onclick="window.location.href='<?php echo e(route('registra')); ?>';" id="reg">Clicca qui per registrarti<img src="<?php echo e(asset('images/signup.png')); ?>"></button>
            <img id="x" src="<?php echo e(asset('images/croce.png')); ?>">
        </div>


        <header>IL MIO SITO</header>
        <p>Uno dei siti di sempre.</p>
    </article>

    <section data-grandezza="piccolo">
        <h2>Le mie Passioni</h2>

        <div class="primo paio">
            <div class="section-item img1">
                <a href='<?php echo e(route('gaming')); ?>'>GAMING</a>
                <img src="<?php echo e(asset('images/unclickedlike.png')); ?>" class="likebutton"  data-numero="1"> 
            </div>

            <div class="section-item img2">
                <a href='<?php echo e(route('music')); ?>'>MUSIC</a>
                <img src="<?php echo e(asset('images/unclickedlike.png')); ?>" class="likebutton"  data-numero="2"> 
            </div>
        </div>

        <div class="paio">
            <div class="section-item img3">
                <p>GYM</p>
                <img src="<?php echo e(asset('images/unclickedlike.png')); ?>" class="likebutton"  data-numero="3"> 
            </div>
            <div class="section-item img4">
                <p>COMPUTER ENGINEERING</p>
                <img src="<?php echo e(asset('images/unclickedlike.png')); ?>" class="likebutton"  data-numero="4"> 
            </div>
        </div>

        <div class="hidden paio" id="terzopaio">
            <div class="section-item img5">
                <p>ANIME</p>
                <img src="<?php echo e(asset('images/unclickedlike.png')); ?>" class="likebutton"  data-numero="5"> 
            </div>
            <div class="section-item img6">
                <p class="API">APIs</p>
                <img src="<?php echo e(asset('images/unclickedlike.png')); ?>" class="likebutton inverti-colori"  data-numero="6"> 
            </div>
        </div>

        <button>Tutte le mie Passioni</button>

    </section>

    <div id="section2"><p>Informazioni universitarie:</p><em>Matricola: 10000303444</em></div>

    <div id="section3">
        <img src="<?php echo e(asset('images/vinland1.avif')); ?>" />
        <p>I have no enemies</p><em>- Thorfinn</em>
    </div>


    <footer>
        <div id="nome">Elia</div>
        <div id="quote">*The quote from above is not to be taken seriously<br>It was added only for comedic purposes</div>
        <img id="thumbsup" src="<?php echo e(asset('images/thumbsup.webp')); ?>"></img>
    </footer>

    <div class="modal-view hidden">
        <img src="<?php echo e(asset('images/croce.png')); ?>" class="croce"> 
        <div id="whiteboard">
            <form id="myForm">
                <label for="artistiagenti">Vuoi vedere i tuoi agenti o i tuoi artisti salvati?:</label>
                <select id="formvalue" name="formvalue">
                     <option value="Artisti">Artisti</option>
                     <option value="Agenti">Agenti</option>
                </select>                               
                <input type="submit">
            </form>
            <div id="contieni-foto"></div>
        </div>
    </div>

</body>
</html>

<?php /**PATH C:\Users\crimi\OneDrive\Desktop\laravel\my-laravel-app\resources\views/welcome.blade.php ENDPATH**/ ?>