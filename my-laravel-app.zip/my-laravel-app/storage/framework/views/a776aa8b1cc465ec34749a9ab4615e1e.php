 <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/accedi.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Madimi+One&display=swap">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>

    <div class="background-image">
        <a href="<?php echo e(route('welcome')); ?>" id="elia">Elia</a>
        <main class="trasparente">
            <h1><?php echo $__env->yieldContent('h1'); ?></h1>
            <form method="post" action="<?php echo e(route('sign')); ?>">
                <?php echo csrf_field(); ?>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="username">

                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="password">

                <input type="submit" value="<?php echo $__env->yieldContent('value'); ?>">
            </form>
        </main>

        <section class="trasparente">
           <?php echo $__env->yieldContent("content"); ?>
        </section>
    </div>

</body>
</html>
<?php /**PATH C:\Users\crimi\OneDrive\Desktop\laravel\my-laravel-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>