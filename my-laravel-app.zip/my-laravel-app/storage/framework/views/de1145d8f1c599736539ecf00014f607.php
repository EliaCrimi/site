<?php $__env->startSection('title', 'GAMING'); ?>

<?php $__env->startSection('script'); ?>                                                                        
    <script src="<?php echo e(asset('js/gaming.js')); ?>" defer></script>                             
<?php $__env->stopSection(); ?>                                                                               
                                                                                          
<?php $__env->startSection('controller', asset('images/controller.png')); ?>                                    
                                                                                          
<?php $__env->startSection('content'); ?>                                                                       
   <p>Genera l'immagine del tuo agente (valorant) preferito!</p>                          
   <form class="gaming">                                                                  
      <label for="agent">Select Agent:</label>                                            
      <select id="agent" name="agent">
           <option value="Gekko">Gekko</option>
           <option value="Fade">Fade</option>
           <option value="Breach">Breach</option>
           <option value="Clove">Clove</option>
           <option value="Deadlock">Deadlock</option>
           <option value="Raze">Raze</option>
           <option value="Chamber">Chamber</option>
           <option value="KAY/O">KAY/O</option>
           <option value="Skye">Skye</option>
           <option value="Cypher">Cypher</option>
           <option value="Sova">Sova</option>
           <option value="Killjoy">Killjoy</option>
           <option value="Harbor">Harbor</option>
           <option value="Viper">Viper</option>
           <option value="Phoenix">Phoenix</option>
           <option value="Astra">Astra</option>
           <option value="Brimstone">Brimstone</option>
           <option value="Iso">Iso</option>
           <option value="Clove">Clove</option>
           <option value="Neon">Neon</option>
           <option value="Yoru">Yoru</option>
           <option value="Sage">Sage</option>
           <option value="Reyna">Reyna</option>
           <option value="Omen">Omen</option>
           <option value="Jett">Jett</option>
      </select>                                                         
      <input type="submit">
   </form>
   <div id="image-container" class="gaming"></div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crimi\OneDrive\Desktop\laravel\my-laravel-app\resources\views/gaming.blade.php ENDPATH**/ ?>