<?php

   use Illuminate\Support\Facades\Route;
   

   Route::get('/', function () {
       return view('welcome');
   })->name('welcome');

   Route::get('/accedi', function () {
       return view('accedi');
   })->name('accedi');
   
   Route::get('/registra', function () {
       return view('registra');
   })->name('registra');

   Route::get('/music', function(){
       return view('music');
   })->name('music');

   Route::get('/gaming', function(){
       return view('gaming');
   })->name('gaming');




   use App\Http\Controllers\SessionController;
   Route::post('/accedi', [SessionController::class, 'login'])->name('accedi.submit');
   Route::get('/logout', [SessionController::class, 'logout'])->name('logout');


   use App\Http\Controllers\RegisterController;
   Route::post('/register', [RegisterController::class, 'register'])->name('sign');


   use App\Http\Controllers\LikeController;
   Route::post('/like', [LikeController::class, 'like'])->name('like');
   Route::get('/likecheck/{numero}', [LikeController::class, 'likecheck'])->name('likecheck');


   use App\Http\Controllers\AgentController;
   Route::get('/agent/{agent_uuid}', [AgentController::class, 'getagent'])->name('getagent');
   Route::post('/agenttable', [AgentController::class, 'AgentTable'])->name('agenttable');


   use App\Http\Controllers\SpotifyController;
   Route::get('/search/{artist}', [SpotifyController::class, 'searchArtist']);
   Route::post('/artisttable', [SpotifyController::class, 'ArtistTable'])->name('artisttable');

   use App\Http\Controllers\APIController;
   Route::get('API/{artistiagentiValue}', [APIController::class, 'table']);



?>
